---
title: ML CD Test
emoji: 🤖
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: "4"     # o quítalo si no quieres fijar versión
app_file: app.py     # <-- tu archivo con Gradio (está en la raíz)
pinned: false
---

App de demo CI/CT/CD. El modelo aprobado se carga desde `models/model-latest.pkl`.
